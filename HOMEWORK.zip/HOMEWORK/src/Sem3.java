public class Sem3 {
    public static void main(String[] args) {
//        Linlist list = new Linlist();
//
//        list.addFirst(3);
//        list.addFirst(7);
//        list.addLast(1);
//        list.print();
//        System.out.println(" ");
//        list.addLast(3);
//        list.addLast(4);
//        list.addFirst(55);
//        list.print();
//        System.out.println(" ");
//        list.revert();
//        list.print();
//        System.out.println(" ");
//        list.revert2();
//        list.print();
//        System.out.println(" ");
//        list.removeFirst();
//        list.print();
//        System.out.println(" ");
//        list.removeLast();
//        list.print();
//        System.out.println(" ");
//        list.revert();
//        list.print();
//        list.contains(7);
        Linlist2 list = new Linlist2();

        list.addLast(1);
        list.addLast(2);
        list.addLast(3);
        list.addLast(4);
        list.addFirst(22);
        list.addFirst(33);
        list.print();
        System.out.println(" ");
        list.removeLast();
        list.removeLast();
        list.removeLast();
        list.addLast(555);
        list.print();
//        list.revert();
//        list.print();
//        System.out.println(" ");
//        list.removeFirst();
//        list.print();
//        System.out.println(" ");
//        list.removeLast();
//        list.print();

    }
}
